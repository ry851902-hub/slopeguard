You are my PRINCIPAL CTO + AI/ML ARCHITECT + GIS ENGINEER + FULL-STACK ENGINEER + DISASTER-MANAGEMENT SYSTEM DESIGNER + DATA SCIENTIST + COMPUTER-VISION ENGINEER + UX DESIGNER + DEVOPS ENGINEER + QA ENGINEER + HACKATHON TECHNICAL LEAD.

We are participating in Smart India Hackathon 2026.

OFFICIAL PROBLEM STATEMENT:

Problem Statement ID:
SIH26001

Title:
AI-Based early warning and landslide Risk Monitoring System in NER

Organization:
Ministry of Development of North Eastern Region (MDoNER)

Category:
Software

Theme:
Disaster Management

IMPORTANT:

This is NOT an academic report.

We must actually BUILD, RUN, DEPLOY if practical, and DEMONSTRATE the working prototype.

Design everything around a realistic 24-hour/rapid hackathon implementation.

Do not create a fantasy system requiring months of research or proprietary government infrastructure.

========================================================
1. UNDERSTAND THE REAL PROBLEM
========================================================

The official problem asks for an AI-enabled early warning and monitoring platform that can:

- collect rainfall data
- collect soil moisture data
- use satellite imagery
- use terrain/slope information
- use historical landslide records
- identify high-risk zones
- predict possible landslide events
- provide alerts
- use GIS
- allow geo-tagged citizen/field reports
- display risk severity
- show road connectivity
- show weather-linked risk
- prioritize emergency response
- support multilingual notifications
- support low-network/offline functionality.

Research and verify the complete official statement before designing the system.

========================================================
2. RESEARCH CURRENT REAL-WORLD SYSTEMS
========================================================

Before coding, research:

1. Geological Survey of India / National Landslide Forecasting Centre / Bhusanket
2. ISRO / NRSC Landslide Atlas
3. NDMA SACHET
4. Existing rainfall-induced landslide early warning systems
5. Existing state-level landslide monitoring systems
6. Existing academic landslide prediction models
7. Existing SIH26001 GitHub repositories
8. Existing open-source GIS systems
9. Open rainfall datasets
10. Open DEM datasets
11. Sentinel/Copernicus datasets
12. Any official or public landslide datasets relevant to Northeast India.

Do NOT pretend these systems do not exist.

Do NOT claim that our project is the first landslide warning system.

We are building an innovation layer around existing capabilities.

For every factual external claim, save:

SOURCE
TITLE
DATE
URL
WHAT IT PROVES
HOW IT AFFECTS OUR DESIGN

========================================================
3. IMPORTANT REAL-WORLD CONTEXT
========================================================

Research current 2026 landslide incidents in the Northeast Region.

Use government sources where possible.

Identify actual examples involving:

- homes
- roads
- bridges
- villages
- emergency connectivity
- evacuation
- field inspections.

Do not exaggerate statistics.

========================================================
4. CORE PRODUCT
========================================================

Build:

SLOPEGUARD

Tagline:

"AI-powered hyperlocal landslide early-warning and response intelligence."

The system should not merely output:

SAFE / UNSAFE

Instead it should answer:

1. What is the current risk?
2. Why is the risk increasing?
3. Where exactly is the risk?
4. What infrastructure is exposed?
5. Which roads may be affected?
6. Which communities may be affected?
7. What field evidence exists?
8. How has the risk changed over time?
9. What should an authority inspect or monitor next?

========================================================
5. IMPORTANT SYSTEM PRINCIPLE
========================================================

Do NOT replace government authorities.

Do NOT automatically order evacuation.

Do NOT make legal or emergency decisions.

The system is:

DECISION SUPPORT.

The final operational decision belongs to authorized authorities.

========================================================
6. CORE ARCHITECTURE
========================================================

Build this architecture:

DATA SOURCES
↓
DATA NORMALIZATION
↓
RISK ENGINE
↓
EXPLAINABILITY
↓
EXPOSURE ENGINE
↓
OPERATIONAL PRIORITY
↓
GIS COMMAND CENTER
↓
FIELD REPORTING
↓
ALERT WORKFLOW
↓
HISTORY / ANALYTICS

========================================================
7. DATA LAYERS
========================================================

Implement these layers:

A. Rainfall
B. Rainfall accumulation
C. Terrain elevation
D. Slope
E. Historical landslides
F. Soil moisture if available
G. Land-use / terrain characteristics where practical
H. Roads
I. Villages
J. Critical infrastructure
K. Field reports
L. Weather/event timeline

Create a clear distinction:

LIVE DATA
SIMULATED DATA
HISTORICAL DATA
SAMPLE DATA

Never pretend simulated data is real.

========================================================
8. RISK ENGINE
========================================================

Build a hybrid risk engine.

Inputs may include:

- rainfall intensity
- 3h rainfall
- 24h rainfall
- cumulative rainfall
- slope
- elevation
- historical landslide density
- soil moisture
- proximity to known landslide zones
- field evidence

Output:

- numerical risk index
- risk class
- uncertainty
- data quality
- top contributing factors.

Possible classes:

LOW
MODERATE
HIGH
CRITICAL
INDETERMINATE

DO NOT state:

"87% probability of landslide"

unless a properly validated statistical model actually supports that interpretation.

Prefer:

"Risk index: 0.87 / HIGH"

========================================================
9. EXPLAINABLE AI
========================================================

Every risk prediction must have an explanation.

Example:

RISK: HIGH

TOP CONTRIBUTORS:

Rainfall accumulation
Slope susceptibility
Historical landslide density
Soil saturation

Also display:

Data quality
Confidence / uncertainty
Timestamp

Create an explainability panel.

========================================================
10. EXPOSURE ENGINE
========================================================

The system must combine HAZARD with EXPOSURE.

Identify:

- nearby roads
- villages
- houses if dataset allows
- schools
- hospitals
- bridges
- utility/infrastructure
- important transport links.

Separate:

HAZARD RISK

from:

EXPOSURE

from:

OPERATIONAL PRIORITY.

Do not claim that this priority formula is an official government standard.

Clearly label it as our prototype decision-support model.

========================================================
11. ROAD RISK
========================================================

This is important.

When a risk zone intersects or approaches a road:

show:

ROAD AT RISK

Road name
Risk
Current status
Potential connectivity impact
Nearby alternatives
Nearby critical locations

Do not automatically declare a real road closed.

Use:

POTENTIAL DISRUPTION
REQUIRES FIELD VERIFICATION

========================================================
12. FIELD REPORTING
========================================================

Create a field/citizen reporting workflow.

User:

Take/upload photo
↓
GPS
↓
Incident type
↓
Severity
↓
Description
↓
Submit

Support incident types:

- ground crack
- slope movement
- rockfall
- road blockage
- debris flow
- water accumulation
- unknown.

Use computer vision only as an assistive classifier.

Output:

Possible crack
Possible rockfall
Possible blockage
Unknown

with confidence.

Never treat computer vision output as definitive ground truth.

========================================================
13. RISK FEEDBACK LOOP
========================================================

When a field report is submitted:

1. Validate GPS
2. Validate image quality
3. Analyse image
4. Associate with risk zone
5. Increase evidence level if appropriate
6. Recalculate risk/priority
7. Send for authority review.

Show visually:

ENVIRONMENTAL DATA
+
FIELD EVIDENCE
=
UPDATED RISK CONTEXT

========================================================
14. RISK TIMELINE
========================================================

Create:

08:00 LOW
10:00 MODERATE
12:00 HIGH
14:00 CRITICAL

The dashboard should show what changed:

Rainfall ↑
Soil moisture ↑
Field report +1

This timeline is essential for the demo.

========================================================
15. MAP
========================================================

Build a professional GIS dashboard.

Layers:

Risk zones
Rainfall
Historical landslides
Roads
Villages
Critical infrastructure
Field reports
Active alerts

Features:

Layer switcher
Search
Location details
Risk popup
Time slider if practical
Legend
Map filters.

========================================================
16. AUTHORITY DASHBOARD
========================================================

Dashboard should contain:

Active risks
High-risk zones
Critical roads
Affected population estimate where available
Pending field verification
Recent alerts
Risk trends
Recent incidents.

Do not fabricate real population or government statistics.

For demo data:

label as DEMO / SIMULATION.

========================================================
17. ALERT SYSTEM
========================================================

Create alert levels:

ADVISORY
WATCH
WARNING
CRITICAL

Each alert must contain:

Location
Time
Risk
Reason
Affected assets
Recommended verification/action
Source
Data quality

Do not issue automatic evacuation commands.

Instead:

"Review evacuation requirement"

or

"Field verification recommended"

========================================================
18. MULTILINGUAL SUPPORT
========================================================

Implement language support using a small controlled set.

For example:

English
Hindi
one relevant Northeast language if feasible.

Do NOT create fake translations.

Make language strings modular so additional languages can be added later.

========================================================
19. OFFLINE / LOW NETWORK
========================================================

Implement a practical offline-first field workflow.

At minimum:

- locally save report
- retain GPS
- queue upload
- sync when connection returns.

Display:

OFFLINE
SYNC PENDING
SYNCED

This directly addresses the official requirement.

========================================================
20. AI / ML STRATEGY
========================================================

DO NOT train huge models from scratch.

Research suitable approaches.

Possible MVP:

Gradient boosting / Random Forest / XGBoost / logistic model

depending on available data.

Compare options.

Use a simple model if it is more reliable.

Generate:

feature importance
validation metrics
confusion matrix where meaningful
limitations.

Never invent model accuracy.

========================================================
21. DATASET PLAN
========================================================

Use defensible public datasets.

Investigate:

ISRO/NRSC Landslide Atlas
GSI resources
NASA GPM IMERG
DEM
Copernicus
OpenStreetMap

Create:

data/README.md

describing:

source
license
date
geographic coverage
resolution
limitations.

========================================================
22. SIMULATION MODE
========================================================

Because full live government data integrations are not guaranteed:

Create a controlled simulation mode.

Example:

Normal
→ rainfall increases
→ soil moisture rises
→ risk increases
→ road becomes exposed
→ field report arrives
→ risk recalculates
→ warning generated.

The simulation must be deterministic and repeatable.

Provide buttons:

START SCENARIO
PAUSE
RESET
INCREASE RAINFALL
ADD FIELD REPORT
SIMULATE LANDSLIDE

========================================================
23. FAILURE MODE
========================================================

If live APIs fail:

the application MUST continue in demo mode.

Implement:

local cached data
sample maps
sample rainfall
sample incidents
sample field images
deterministic simulation.

The judge must still see the complete workflow.

========================================================
24. PRODUCT SCREENS
========================================================

Build:

1. Landing
2. Authority Dashboard
3. GIS Risk Map
4. Risk Detail
5. Risk Explanation
6. Field Reporting
7. Field Report Review
8. Road Impact
9. Alert Center
10. Historical Incidents
11. Analytics
12. Settings / Data Sources.

Only build screens that support the demo.

========================================================
25. DEMO STORY
========================================================

Create ONE polished scenario based on a fictional/demo location in the Northeast.

Do not pretend that a simulated event is a real current event.

Scenario:

1. Dashboard starts normal.
2. Rainfall increases.
3. Risk changes.
4. Explainability panel identifies drivers.
5. Road exposure appears.
6. Field officer uploads a crack photo.
7. Computer vision classifies possible slope crack.
8. Risk context updates.
9. Authority receives warning.
10. Field verification task is created.
11. Timeline shows evolution.
12. Report generated.

Target:

2–3 minute demo.

========================================================
26. 30-SECOND FALLBACK
========================================================

Create a one-click demo:

LOAD DEMO SCENARIO

Everything populates instantly.

Then demonstrate:

Risk map
→ risk explanation
→ road exposure
→ field evidence
→ alert.

========================================================
27. GITHUB
========================================================

Create a professional repository:

slopegurad/
├── apps/
│   ├── web/
│   └── field-app/
├── backend/
│   ├── api/
│   ├── services/
│   └── database/
├── ml/
│   ├── risk_model/
│   ├── image_model/
│   └── preprocessing/
├── gis/
├── data/
├── simulation/
├── alerts/
├── tests/
├── docs/
├── scripts/
├── .env.example
├── .gitignore
├── README.md
├── LICENSE
└── docker-compose.yml

Modify only if a simpler architecture is genuinely better.

========================================================
28. DATABASE
========================================================

Create models for:

RiskZone
RainfallObservation
TerrainCell
LandslideEvent
RoadSegment
Village
Infrastructure
FieldReport
Alert
RiskSnapshot
InspectionTask
User
AuditEvent.

Include relationships.

========================================================
29. API DESIGN
========================================================

Design APIs for:

GET /risk-zones
GET /risk/:id
POST /field-reports
POST /risk/recalculate
GET /roads/affected
GET /historical-events
GET /alerts
POST /alerts
GET /risk-history/:id
POST /simulation/start
POST /simulation/reset
POST /simulation/rainfall
POST /simulation/field-report

Provide request and response examples.

========================================================
30. TESTING
========================================================

Test:

Rainfall update
Risk calculation
Risk classification
Missing data
Field report
Image classification failure
GPS failure
Road intersection
Alert creation
Risk history
Simulation reset
Offline sync
API failure
Database failure.

Build automated tests.

========================================================
31. SECURITY
========================================================

Implement:

Input validation
File validation
File-size limits
authentication
role-based access
secure environment variables
rate limiting where practical
audit logs
safe image handling.

Never put API secrets in GitHub.

========================================================
32. LEGAL / SAFETY
========================================================

The platform is:

DECISION SUPPORT.

Do not claim:

- guaranteed prediction
- guaranteed early warning
- guaranteed evacuation safety
- government approval
- official government integration
- live emergency authority connection
- scientific certification.

Every demo-only function must be labelled DEMO/SIMULATION.

========================================================
33. UI/UX
========================================================

Design like a professional disaster-management command centre.

The main screen should immediately communicate:

WHERE
WHAT
HOW SERIOUS
WHY
WHO/WHAT IS EXPOSED
WHAT HAPPENS NEXT

Avoid generic SaaS dashboard design.

The map should be the visual center.

========================================================
34. RESEARCH REPORT
========================================================

Before coding, produce:

1. Official problem analysis
2. Real-world evidence
3. Existing government systems
4. Existing research
5. Existing SIH26001 repositories
6. Competitive gap
7. Proposed innovation
8. Dataset strategy
9. Model strategy
10. System architecture
11. Technical risks
12. Demo strategy.

Every factual claim must have a source.

========================================================
35. 24-HOUR BUILD PLAN
========================================================

Create a realistic plan:

Hour 0–1:
Architecture + repository

Hour 1–3:
Frontend shell + database

Hour 3–6:
GIS map + demo datasets

Hour 6–10:
Risk engine

Hour 10–13:
Risk explanations + timeline

Hour 13–16:
Field report + CV

Hour 16–19:
Road/exposure engine + alerts

Hour 19–21:
Simulation

Hour 21–23:
Testing + deployment

Hour 23–24:
Demo + documentation + backup.

Assign exact work to six people.

========================================================
36. MVP PRIORITY
========================================================

MUST HAVE:

- GIS map
- risk engine
- risk explanation
- rainfall simulation
- historical events
- road exposure
- field report
- alert
- risk timeline
- demo mode.

SHOULD HAVE:

- CV
- offline sync
- satellite layer
- multilingual notification.

CUT IF LATE:

advanced satellite ML
large-scale crawling
complex authentication
real SMS integration
advanced mobile application.

========================================================
37. JUDGE QUESTIONS
========================================================

Prepare factual answers for:

Why is this different from GSI?
Why is this different from SACHET?
Where does the data come from?
How does AI work?
How do you validate the model?
What happens with missing data?
What if the prediction is wrong?
How is false alarm handled?
Can it work offline?
Can it scale to the entire Northeast?
Can it integrate with government systems?
What is simulated?
What is real?
What would be required for real deployment?

========================================================
38. MOST IMPORTANT DIFFERENTIATION
========================================================

Our solution is not:

"another landslide heatmap."

It should be:

ENVIRONMENTAL SIGNALS
+
AI RISK ESTIMATION
+
EXPLAINABLE DRIVERS
+
FIELD EVIDENCE
+
INFRASTRUCTURE EXPOSURE
+
RISK EVOLUTION
+
AUTHORITY WORKFLOW

Build the product around this.

========================================================
39. FINAL OUTPUT BEFORE CODING
========================================================

Return:

A. Executive summary
B. Official problem statement interpretation
C. Research findings
D. Existing-system analysis
E. Genuine gap
F. Final product definition
G. Unique capabilities
H. Architecture
I. Data sources
J. ML approach
K. Risk formula
L. Database
M. APIs
N. UI screens
O. GitHub tree
P. Team tasks
Q. 24-hour plan
R. Demo script
S. Testing plan
T. Security
U. Deployment
V. Limitations
W. Future scope
X. Sources

Then begin implementation.

DO NOT GENERATE THOUSANDS OF LINES OF CODE IN ONE RESPONSE.

Build incrementally.

After every significant module:

RUN
TEST
BUILD
CHECK ERRORS
FIX
DOCUMENT

Never claim a feature works unless it has actually been tested.

FINAL SECTION MUST BE:

"MVP CORE — BUILD FIRST"

"CUT IF TIME RUNS OUT"

"WHAT IS REAL VS SIMULATED"

"WHAT THE JUDGE MUST REMEMBER"

"KNOWN LIMITATIONS"

"RESEARCH SOURCES"