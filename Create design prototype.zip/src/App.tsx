import React, { useState, useEffect } from 'react';
import {
  AlertTriangle, MapPin, Search, Layers, Play, Pause, Activity,
  Camera, AlertCircle, Clock, ShieldAlert, CloudRain,
  Navigation, Map as MapIcon, ChevronRight, CheckCircle2, FileText, Send, Smartphone
} from 'lucide-react';

// Data models
type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

const RISK_COLORS: Record<RiskLevel, string> = {
  LOW: 'text-low border-low/30 bg-low/10',
  MODERATE: 'text-moderate border-moderate/30 bg-moderate/10',
  HIGH: 'text-high border-high/30 bg-high/10',
  CRITICAL: 'text-critical border-critical/30 bg-critical/10',
};

const RISK_BG: Record<RiskLevel, string> = {
  LOW: 'bg-low',
  MODERATE: 'bg-moderate',
  HIGH: 'bg-high',
  CRITICAL: 'bg-critical',
};

export default function App() {
  const [simulating, setSimulating] = useState(false);
  const [simTime, setSimTime] = useState(8); // 8:00 AM
  const [showFieldApp, setShowFieldApp] = useState(false);
  const [fieldSyncStatus, setFieldSyncStatus] = useState<'OFFLINE' | 'SYNC_PENDING' | 'SYNCED'>('OFFLINE');

  // Simulation loop
  useEffect(() => {
    let interval: number;
    if (simulating) {
      interval = window.setInterval(() => {
        setSimTime((prev) => (prev >= 23 ? 0 : prev + 1));
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [simulating]);

  const simulateFieldSync = () => {
    setFieldSyncStatus('SYNC_PENDING');
    setTimeout(() => setFieldSyncStatus('SYNCED'), 1500);
    setTimeout(() => {
      setShowFieldApp(false);
      setFieldSyncStatus('OFFLINE');
    }, 3000);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-background text-foreground font-sans text-sm">
      {/* HEADER */}
      <header className="flex-none h-14 border-b border-border flex items-center justify-between px-4 bg-card z-10 relative">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-critical font-bold tracking-wider text-base uppercase">
            <ShieldAlert size={20} />
            SlopeGuard <span className="text-muted-foreground font-mono font-medium text-xs ml-2">NER / MDoNER</span>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <button 
            onClick={() => setShowFieldApp(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-md font-mono text-xs font-medium text-muted-foreground border border-border hover:bg-muted transition-colors"
          >
            <Smartphone size={14} />
            OPEN FIELD APP SIMULATOR
          </button>
          
          <div className="flex items-center gap-3 bg-background border border-border rounded-md px-3 py-1">
            <Clock size={16} className="text-muted-foreground" />
            <span className="font-mono">{String(simTime).padStart(2, '0')}:00 HRS</span>
          </div>

          <div className="flex items-center gap-2 border-l border-border pl-6">
            <span className="text-xs font-mono text-muted-foreground mr-2">SIMULATION MODE</span>
            <button
              onClick={() => setSimulating(!simulating)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md font-mono text-xs font-medium transition-colors ${
                simulating
                  ? 'bg-critical text-critical-foreground hover:bg-critical/90'
                  : 'bg-primary text-primary-foreground border border-border hover:bg-muted'
              }`}
            >
              {simulating ? <Pause size={14} /> : <Play size={14} />}
              {simulating ? 'PAUSE' : 'START SCENARIO'}
            </button>
            <button className="px-3 py-1.5 bg-primary text-primary-foreground border border-border rounded-md font-mono text-xs font-medium hover:bg-muted">
              RESET
            </button>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT GRID */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* LEFT PANEL: Authority Dashboard */}
        <aside className="w-80 flex-none border-r border-border bg-card flex flex-col z-10 relative">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-xs text-muted-foreground uppercase tracking-wider">Authority Dashboard</h2>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {/* Active Risks */}
            <section className="space-y-3">
              <h3 className="font-mono text-xs text-muted-foreground flex items-center gap-2">
                <Activity size={14} /> Active High-Risk Zones
              </h3>
              
              <div className="space-y-2">
                <RiskCard 
                  location="NH-10, Gangtok Sector" 
                  risk="CRITICAL" 
                  trend="up" 
                  population="1.2k" 
                />
                <RiskCard 
                  location="Mangan District, Zone 4" 
                  risk="HIGH" 
                  trend="stable" 
                  population="840" 
                />
                <RiskCard 
                  location="Siliguri Corridor Appx" 
                  risk="MODERATE" 
                  trend="up" 
                  population="3.5k" 
                />
              </div>
            </section>

            {/* Critical Roads */}
            <section className="space-y-3">
              <h3 className="font-mono text-xs text-muted-foreground flex items-center gap-2">
                <Navigation size={14} /> Critical Road Exposure
              </h3>
              
              <div className="bg-background border border-border rounded-md p-3 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-medium text-sm">NH-10 (Sevoke - Gangtok)</div>
                    <div className="text-xs text-muted-foreground">KM 14.5 - Landslide intersect</div>
                  </div>
                  <span className="bg-high/10 text-high border border-high/20 px-2 py-0.5 rounded text-[10px] font-mono font-bold">EXPOSED</span>
                </div>
                <div className="flex gap-2 text-xs">
                  <span className="text-muted-foreground font-mono">Status:</span> 
                  <span className="text-high">Verification Required</span>
                </div>
                <button className="w-full text-xs font-mono border border-border py-1.5 rounded hover:bg-muted transition-colors">
                  DISPATCH FIELD TEAM
                </button>
              </div>
            </section>

            {/* Field Verification Tasks */}
            <section className="space-y-3">
              <h3 className="font-mono text-xs text-muted-foreground flex items-center gap-2">
                <CheckCircle2 size={14} /> Pending Verifications
              </h3>
              
              <div className="flex items-center gap-3 p-3 border border-border rounded-md bg-background hover:bg-muted/50 cursor-pointer transition-colors">
                <div className="bg-accent p-2 rounded-md">
                  <Camera size={16} className="text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-xs truncate">Citizen Report: Ground Crack</div>
                  <div className="text-[10px] text-muted-foreground font-mono mt-1">10 mins ago • Zone 4</div>
                </div>
                <ChevronRight size={14} className="text-muted-foreground" />
              </div>
            </section>
          </div>
        </aside>

        {/* CENTER PANEL: Map area */}
        <main className="flex-1 relative bg-[#1c1c1e]">
          {/* Faux Map Background using CSS pattern */}
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#3f3f46 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          
          {/* Map Controls */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <button className="p-2 bg-card border border-border rounded-md hover:bg-muted text-muted-foreground hover:text-foreground shadow-sm">
              <Layers size={18} />
            </button>
            <button className="p-2 bg-card border border-border rounded-md hover:bg-muted text-muted-foreground hover:text-foreground shadow-sm">
              <Search size={18} />
            </button>
            <button className="p-2 bg-card border border-border rounded-md hover:bg-muted text-muted-foreground hover:text-foreground shadow-sm">
              <MapIcon size={18} />
            </button>
          </div>

          {/* Map Legend */}
          <div className="absolute bottom-4 left-4 bg-card/90 backdrop-blur border border-border rounded-md p-3 text-xs font-mono shadow-lg">
            <div className="font-medium mb-2 text-muted-foreground">RISK INDEX</div>
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-sm bg-critical"></div> Critical (&gt;0.8)</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-sm bg-high"></div> High (0.6-0.8)</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-sm bg-moderate"></div> Moderate (0.4-0.6)</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-sm bg-low"></div> Low (&lt;0.4)</div>
            </div>
          </div>

          {/* Mock Map Elements */}
          {/* Zone 1 */}
          <div className="absolute top-1/3 left-1/3 w-48 h-48 border-2 border-high/50 bg-high/10 rounded-full flex items-center justify-center animate-pulse">
            <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-card border border-high/50 px-2 py-1 rounded text-xs font-mono flex items-center gap-1 shadow-lg">
              <div className="w-2 h-2 rounded-full bg-high"></div>
              <span>ZONE 4</span>
            </div>
            <MapPin size={24} className="text-high" />
          </div>

          {/* Zone 2 (Critical) */}
          <div className="absolute top-1/2 left-2/3 w-32 h-32 border-2 border-critical/50 bg-critical/20 rounded-full flex items-center justify-center">
            <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-card border border-critical/50 px-2 py-1 rounded text-xs font-mono flex items-center gap-1 shadow-lg">
              <div className="w-2 h-2 rounded-full bg-critical animate-ping"></div>
              <span>NH-10</span>
            </div>
            <MapPin size={24} className="text-critical" />
          </div>

          {/* Faux Road */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ filter: 'drop-shadow(0 0 4px rgba(255,255,255,0.1))' }}>
             <path d="M 0 400 Q 300 400 400 200 T 800 300 T 1200 100" fill="none" stroke="#3f3f46" strokeWidth="4" strokeDasharray="8 8" />
             <path d="M 0 400 Q 300 400 400 200 T 800 300 T 1200 100" fill="none" stroke="#fafafa" strokeWidth="2" strokeDasharray="8 8" opacity="0.5" />
          </svg>
        </main>

        {/* RIGHT PANEL: Explainability & Field */}
        <aside className="w-[360px] flex-none border-l border-border bg-card flex flex-col z-10 relative">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-xs text-muted-foreground uppercase tracking-wider">Risk Analysis: NH-10</h2>
            <span className="bg-critical/10 text-critical border border-critical/20 px-2 py-0.5 rounded text-[10px] font-mono font-bold">0.87 / CRITICAL</span>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            
            {/* AI Risk Explanation */}
            <section className="space-y-3">
              <h3 className="font-mono text-xs text-muted-foreground flex items-center gap-2">
                <Activity size={14} /> Explainable AI Drivers
              </h3>
              
              <div className="space-y-3 bg-background border border-border p-3 rounded-md">
                <DriverRow label="Rainfall Accumulation (72h)" value="184mm" contribution={45} type="high" />
                <DriverRow label="Soil Saturation Index" value="92%" contribution={30} type="high" />
                <DriverRow label="Slope Susceptibility" value="38°" contribution={15} type="moderate" />
                <DriverRow label="Field Evidence (Cracks)" value="+1" contribution={10} type="high" />
                
                <div className="pt-2 mt-2 border-t border-border flex justify-between text-[10px] font-mono text-muted-foreground">
                  <span>Confidence: 89%</span>
                  <span>Model: XGB-Env v2.1</span>
                </div>
              </div>
            </section>

            {/* Weather Context */}
            <section className="space-y-3">
              <h3 className="font-mono text-xs text-muted-foreground flex items-center gap-2">
                <CloudRain size={14} /> Environmental Data
              </h3>
              
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-background border border-border p-2 rounded flex flex-col gap-1">
                  <span className="text-[10px] text-muted-foreground font-mono">Current Rain</span>
                  <span className="font-mono font-medium text-sm">24 mm/h</span>
                </div>
                <div className="bg-background border border-border p-2 rounded flex flex-col gap-1">
                  <span className="text-[10px] text-muted-foreground font-mono">Forecast (12h)</span>
                  <span className="font-mono font-medium text-sm text-high">+140 mm</span>
                </div>
              </div>
            </section>

            {/* Field Report Snapshot */}
            <section className="space-y-3">
              <h3 className="font-mono text-xs text-muted-foreground flex items-center gap-2">
                <AlertCircle size={14} /> Field Evidence
              </h3>
              
              <div className="bg-background border border-border p-3 rounded-md space-y-3">
                <div className="aspect-video bg-muted rounded border border-border flex flex-col items-center justify-center text-muted-foreground overflow-hidden relative">
                  {/* Mock Image using CSS */}
                  <div className="absolute inset-0 bg-primary opacity-50 mix-blend-overlay"></div>
                  <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1623847939103-68d89e023d8c?w=400&h=300&fit=crop')] bg-cover bg-center grayscale opacity-60"></div>
                  <div className="absolute top-2 right-2 bg-black/80 backdrop-blur text-[10px] font-mono text-high px-1.5 py-0.5 rounded border border-high/30 z-10 flex items-center gap-1">
                    <Activity size={10} />
                    CV: Possible Crack (88%)
                  </div>
                </div>
                
                <div>
                  <div className="text-xs font-medium">Citizen Report #4412</div>
                  <div className="text-[10px] text-muted-foreground font-mono mt-0.5">Reported via Offline Sync App</div>
                </div>
                <div className="flex gap-2">
                  <button className="flex-1 py-1.5 bg-primary text-primary-foreground border border-border text-[10px] font-mono font-medium rounded hover:bg-muted">
                    IGNORE
                  </button>
                  <button className="flex-1 py-1.5 bg-high text-high-foreground text-[10px] font-mono font-bold rounded hover:bg-high/90">
                    VERIFY RISK
                  </button>
                </div>
              </div>
            </section>

          </div>
        </aside>

      </div>

      {/* FIELD APP SIMULATOR MODAL */}
      {showFieldApp && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="w-[320px] h-[640px] bg-[#121214] border border-border rounded-3xl shadow-2xl flex flex-col overflow-hidden relative">
            {/* Phone Notch/Status Bar mock */}
            <div className="h-8 bg-black w-full flex items-center justify-between px-6 text-[10px] font-mono text-muted-foreground">
              <span>{String(simTime).padStart(2, '0')}:00</span>
              <div className="flex gap-1 items-center">
                <span className={fieldSyncStatus === 'OFFLINE' ? 'text-critical' : 'text-low'}>{fieldSyncStatus}</span>
              </div>
            </div>
            
            {/* Field App Header */}
            <div className="bg-card p-4 border-b border-border flex justify-between items-center">
              <span className="font-bold tracking-wider">Field Reporter</span>
              <button onClick={() => setShowFieldApp(false)} className="text-muted-foreground hover:text-foreground">
                Close
              </button>
            </div>

            {/* Field App Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm">
              <div className="space-y-1">
                <label className="text-xs font-mono text-muted-foreground">GPS LOCATION</label>
                <div className="bg-background border border-border p-2 rounded flex justify-between font-mono text-xs">
                  <span>27.3314° N, 88.6138° E</span>
                  <MapPin size={14} className="text-primary-foreground" />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono text-muted-foreground">INCIDENT TYPE</label>
                <select className="w-full bg-background border border-border p-2 rounded font-mono text-xs outline-none">
                  <option>Ground Crack</option>
                  <option>Slope Movement</option>
                  <option>Rockfall</option>
                  <option>Road Blockage</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono text-muted-foreground">EVIDENCE (PHOTO)</label>
                <div className="aspect-video bg-muted border border-border border-dashed rounded flex flex-col items-center justify-center text-muted-foreground hover:bg-muted/80 cursor-pointer">
                  <Camera size={24} className="mb-2" />
                  <span className="text-xs font-mono">TAP TO CAPTURE</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono text-muted-foreground">DESCRIPTION</label>
                <textarea 
                  className="w-full h-20 bg-background border border-border p-2 rounded font-mono text-xs outline-none resize-none"
                  placeholder="Enter details here..."
                  defaultValue="2cm wide crack forming along retaining wall near KM 14.5"
                ></textarea>
              </div>
            </div>

            {/* Field App Footer / Action */}
            <div className="p-4 bg-card border-t border-border">
              <button 
                onClick={simulateFieldSync}
                disabled={fieldSyncStatus !== 'OFFLINE'}
                className="w-full py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded font-mono text-xs font-bold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Send size={16} />
                {fieldSyncStatus === 'OFFLINE' ? 'SAVE & QUEUE FOR SYNC' : fieldSyncStatus === 'SYNC_PENDING' ? 'SYNCING...' : 'SYNC COMPLETE'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Subcomponents

function RiskCard({ location, risk, trend, population }: { location: string, risk: RiskLevel, trend: 'up'|'down'|'stable', population: string }) {
  return (
    <div className={`border p-3 rounded-md flex flex-col gap-2 ${RISK_COLORS[risk]}`}>
      <div className="flex justify-between items-start">
        <span className="font-medium text-xs">{location}</span>
        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${RISK_BG[risk]} text-black`}>{risk}</span>
      </div>
      <div className="flex justify-between items-end text-[10px] font-mono opacity-80">
        <div className="flex items-center gap-1">
          <AlertTriangle size={12} />
          Pop: {population}
        </div>
        <div className="flex items-center gap-1 uppercase">
          Trend: {trend}
        </div>
      </div>
    </div>
  )
}

function DriverRow({ label, value, contribution, type }: { label: string, value: string, contribution: number, type: 'high'|'moderate'|'low' }) {
  const barColor = type === 'high' ? 'bg-high' : type === 'moderate' ? 'bg-moderate' : 'bg-low';
  
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono font-medium">{value}</span>
      </div>
      <div className="flex items-center gap-2">
        <div className="h-1.5 flex-1 bg-muted rounded-full overflow-hidden">
          <div className={`h-full ${barColor}`} style={{ width: `${contribution}%` }}></div>
        </div>
        <span className="text-[10px] font-mono w-6 text-right text-muted-foreground">{contribution}%</span>
      </div>
    </div>
  )
}
